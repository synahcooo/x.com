# X Web App (Android)

独立 Android WebView 壳，默认打开 https://x.com/。

## 当前实现
- Android WebView + JavaScript/DOM storage，支持 X 的动态网页。
- Android 返回键优先返回网页历史。
- 仅允许 HTTPS 的 X/Twitter 及其子域名在应用内导航；其他站外链接会被拦截，不自动拉起外部应用。
- 主站 WebView 禁止本地文件和内容访问，并在当前 WebView 组件支持时启用 Safe Browsing。
- 对截图中提到的获取应用、手机、Google、Apple入口尝试进行点击拦截，并显示通用未授权提示。
- 不包含菜鸟云注入，不包含星跃品牌元素。

## 构建
使用 Android Studio 打开项目，安装 Android SDK 35，使用 JDK 17，然后 Build > Build Bundle(s) / APK(s) > Build APK(s)。

命令行：`gradle :app:assembleDebug`

输出：`app/build/outputs/apk/debug/app-debug.apk`

## 重要说明
1. X.com 是动态网站，DOM 文案、按钮结构和登录流程会变化。当前拦截基于可见文案、ARIA 标签、链接地址及部分测试标识，并通过捕获阶段点击事件处理；仍必须在目标设备上逐项测试，不能保证覆盖所有语言、AB 测试和未来页面改版。
2. 入口提示通过 WebView JavaScript alert 回调到 Android 原生 AlertDialog 显示，按钮为“我知道了”。
3. APK 文件体积要求严格大于 20 MiB。当前加入了约 1.67 MiB 的离线中文安全教程图文资源，但这并不意味着 APK 已达到 20 MiB；GitHub Actions 会在构建后实测，不达标就失败。不会使用随机填充或重复垃圾资源凑体积。
4. 此工程尚未在本环境完成编译、安装和真机验证。不要把源码包视为已交付 APK。当前环境没有 Gradle/Android SDK，无法在这里生成 APK。
5. X 商标及服务归 X Corp.；应用图标、名称和发布方式应遵守其品牌与服务条款。


## APK size acceptance criterion
The GitHub Actions workflow now enforces a strict APK file size greater than 20 MiB (20 × 1024 × 1024 bytes). A build below this threshold fails rather than being reported as compliant. The project does not add random padding or duplicated junk data. To reach the threshold legitimately, add real bundled features/assets that have a user-facing purpose (for example, a substantial offline help/tutorial media pack), then verify the final APK size.


## WebView hardening
主站 WebView 禁用 file/content 访问、禁止混合内容，并在组件支持时开启 Safe Browsing。导航仅放行 HTTPS 的 x.com、twitter.com、twimg.com 及其子域名；其他地址会被拦截。Android 23+ 同时覆盖新旧导航回调。

## Offline help center
The app now bundles `app/src/main/assets/help.html`, a locally available help guide covering login steps, 2FA safety, phone/email binding, recovery codes, account protection, network troubleshooting, restricted entry explanations, and official help links. A locally bundled Chinese infographic is included. A native “帮助” control opens it without a network request.
