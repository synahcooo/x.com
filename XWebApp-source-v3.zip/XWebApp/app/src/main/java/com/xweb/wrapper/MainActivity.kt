package com.xweb.wrapper

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val home = "https://x.com/"
    private var pageReady = false
    private lateinit var rootLayout: FrameLayout

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false

        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadsImagesAutomatically = true
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                cacheMode = WebSettings.LOAD_DEFAULT
                userAgentString = userAgentString.replace("; wv", "")
                mediaPlaybackRequiresUserGesture = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                // The main X page does not need local-file access. Keep it disabled
                // to reduce the impact of any web-content compromise.
                allowFileAccess = false
                allowContentAccess = false
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.SAFE_BROWSING_ENABLE)) {
                WebSettingsCompat.setSafeBrowsingEnabled(settings, true)
            }
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webChromeClient = object : WebChromeClient() {
                override fun onJsAlert(
                    view: WebView?,
                    url: String?,
                    message: String?,
                    result: android.webkit.JsResult?
                ): Boolean {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("提示")
                        .setMessage(message ?: "此功能暂不可用")
                        .setPositiveButton("我知道了") { dialog, _ ->
                            result?.confirm()
                            dialog.dismiss()
                        }
                        .setOnCancelListener { result?.confirm() }
                        .show()
                    return true
                }
            }
            webViewClient = object : WebViewClient() {
                @Suppress("DEPRECATION")
                override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                    return isAllowedInAppUrl(url)
                }

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    return isAllowedInAppUrl(request.url.toString())
                }
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    injectEntryGuard()
                    pageReady = true
                }
            }
        }
        rootLayout = FrameLayout(this)
        rootLayout.addView(web, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT
        ))
        val helpButton = TextView(this).apply {
            text = "帮助"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(28, 16, 28, 16)
            setBackgroundColor(Color.rgb(35, 35, 35))
            elevation = 12f
            setOnClickListener { showOfflineHelp() }
        }
        val helpParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END
        ).apply { topMargin = dp(12); marginEnd = dp(12) }
        rootLayout.addView(helpButton, helpParams)
        setContentView(rootLayout)
        if (savedInstanceState == null) web.loadUrl(home) else web.restoreState(savedInstanceState)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else {
                    web.evaluateJavascript("history.length > 1") { canGo ->
                        if (canGo == "true") web.goBack() else finish()
                    }
                }
            }
        })
    }

    // true means WebView should not navigate: only HTTPS X/Twitter media and
    // first-party domains stay in this app. Other destinations are intentionally blocked.
    private fun isAllowedInAppUrl(rawUrl: String): Boolean {
        return try {
            val uri = android.net.Uri.parse(rawUrl)
            val host = uri.host?.lowercase() ?: return true
            val allowedHost = host == "x.com" || host.endsWith(".x.com") ||
                host == "twitter.com" || host.endsWith(".twitter.com") ||
                host == "twimg.com" || host.endsWith(".twimg.com")
            !(uri.scheme.equals("https", ignoreCase = true) && allowedHost)
        } catch (_: Exception) {
            true
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun showOfflineHelp() {
        val help = WebView(this).apply {
            settings.javaScriptEnabled = false
            settings.domStorageEnabled = false
            loadUrl("file:///android_asset/help.html")
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("使用帮助")
            .setView(help)
            .setPositiveButton("关闭", null)
            .create()
        dialog.setOnDismissListener { help.destroy() }
        dialog.show()
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94f).toInt(),
            (resources.displayMetrics.heightPixels * 0.82f).toInt()
        )
    }

    private fun injectEntryGuard() {
        val script = """
          (function(){
            if (window.__xWrapperGuardInstalled) return;
            window.__xWrapperGuardInstalled = true;

            const googlePattern = /(google|谷歌)/i;
            const applePattern = /(apple)/i;
            const phonePattern = /(phone|mobile|手机号|手机)/i;
            const appPattern = /(get the app|download the app|获取应用|下载应用)/i;

            function textOf(node) {
              return ((node.innerText || node.getAttribute('aria-label') ||
                node.getAttribute('title') || node.value || '')
                .trim().replace(/\s+/g, ' '));
            }

            function notify(message) {
              window.alert(message);
            }

            function intercept(event) {
              const path = typeof event.composedPath === 'function'
                ? event.composedPath() : [event.target];
              for (const candidate of path.slice(0, 8)) {
                const node = candidate && candidate.nodeType === 1 ? candidate : null;
                if (!node || !node.getAttribute) continue;
                const actionable = node.matches('a,button,[role="button"],input[type="button"],input[type="submit"]')
                  ? node : node.closest('a,button,[role="button"],input[type="button"],input[type="submit"]');
                if (!actionable) continue;
                const label = textOf(actionable);
                const href = actionable.getAttribute('href') || '';
                const testId = actionable.getAttribute('data-testid') || '';
                const combined = label + ' ' + href + ' ' + testId;

                const isGoogle = googlePattern.test(combined) &&
                  /(sign.?in|continue|login|oauth|google|谷歌)/i.test(combined);
                const isApple = applePattern.test(combined) &&
                  /(sign.?in|continue|login|apple)/i.test(combined);
                const isPhone = phonePattern.test(combined) &&
                  /(sign.?in|continue|login|phone|mobile|手机|手机号)/i.test(combined);
                const isApp = appPattern.test(combined);

                if (isGoogle || isApple || isPhone || isApp) {
                  event.preventDefault();
                  event.stopPropagation();
                  if (event.stopImmediatePropagation) event.stopImmediatePropagation();
                  if (isGoogle) {
                    notify('正在准备 Google 登录资源\n\n此入口当前受限。此提示仅说明入口状态，不代表应用正在后台下载或安装 Google Play 服务。请使用页面提供的其他可用登录方式。');
                  } else if (isApple) {
                    notify('Apple 登录暂不可用\n\n当前应用暂未开放 Apple 登录入口，请使用其他可用方式。');
                  } else if (isPhone) {
                    notify('手机登录暂不可用\n\n当前应用暂未开放此登录入口，请使用其他可用方式。');
                  } else {
                    notify('获取应用暂不可用\n\n当前应用暂未开放应用下载入口。');
                  }
                  return;
                }
                // Only inspect the nearest actionable element once.
                if (actionable !== node) break;
              }
            }

            document.addEventListener('click', intercept, true);
          })();
        """.trimIndent()
        web.evaluateJavascript(script, null)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (::web.isInitialized) { web.stopLoading(); web.destroy() }
        super.onDestroy()
    }
}
