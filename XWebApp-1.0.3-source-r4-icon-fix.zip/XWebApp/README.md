# X Client Android

An independent Android application that opens X and applies local entry restrictions for selected sign-in methods. App version label: 12.40.0; Android versionCode: 4.

## Icon and bundled image assets

The launcher icon uses a high-resolution black-and-white X-inspired mark, with density-specific Android launcher assets. The APK also bundles `app/src/main/assets/x_icon_master_14336.png` (about 22.5 MB) locally; it does not need to be downloaded at runtime. This large master image is an internal bundled asset and is separate from the small launcher icon files.

## Build

Run the GitHub Actions workflow `Build X Client APK`, or build with Gradle 8.9, JDK 17, Android SDK Platform 35, and Build Tools 35.0.0.

## Sign-in entry restrictions

The app blocks Google sign-in, Apple sign-in, Get App, and phone-number sign-in. Guards run during click, pointer, keyboard activation, and form submission. Username-based sign-in is intended to remain available. The phone-flow guard checks the surrounding authentication form so a generic Continue button in a phone-number form is blocked without blanket-blocking username Continue buttons. A navigation-level guard also blocks Google/Apple authorization destinations.

The app is an independent third-party client and is not affiliated with or endorsed by X Corp.


### Launcher icon and bundled image verification (r4)
- Legacy density launcher icons are retained for older Android launchers.
- Android 8.0+ uses adaptive launcher icon XML with a black background and transparent white X foreground.
- The bundled high-resolution PNG in `app/src/main/assets/` is configured as uncompressed (`androidResources.noCompress += "png"`) so it remains close to its original size inside the APK.
- Verify the built APK with `unzip -l app/build/outputs/apk/debug/app-debug.apk` and confirm `assets/x_icon_master_14336.png` is approximately 22.5 MB.
- This source change has not been claimed as a successful Android build until GitHub Actions completes and the installed launcher icon is checked on a device.
