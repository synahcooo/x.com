package com.xweb.wrapper

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private val home = "https://x.com/"
    private var pageReady = false
    private var lastKnownUrl: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false

        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                loadsImagesAutomatically = true
                javaScriptCanOpenWindowsAutomatically = false
                setSupportMultipleWindows(false)
                cacheMode = WebSettings.LOAD_DEFAULT
                userAgentString = userAgentString.replace("; wv", "")
                mediaPlaybackRequiresUserGesture = true
                mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            }
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webChromeClient = object : WebChromeClient() {
                override fun onJsAlert(
                    view: WebView?,
                    url: String?,
                    message: String?,
                    result: android.webkit.JsResult?
                ): Boolean {
                    AlertDialog.Builder(this@MainActivity)
                        .setTitle("提示")
                        .setMessage(message ?: "此功能暂不可用")
                        .setPositiveButton("我知道了") { dialog, _ ->
                            result?.confirm()
                            dialog.dismiss()
                        }
                        .setOnCancelListener { result?.confirm() }
                        .show()
                    return true
                }
            }
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    val host = uri.host.orEmpty().lowercase()
                    val urlText = uri.toString().lowercase()
                    // A blocked sign-in destination must remain blocked even if the site navigates
                    // programmatically instead of producing a normal button click.
                    val isGoogleAuth = (host == "accounts.google.com" || host.endsWith(".google.com")) &&
                        (urlText.contains("oauth") || urlText.contains("signin") || urlText.contains("service="))
                    val isAppleAuth = (host == "appleid.apple.com" || host.endsWith(".apple.com")) &&
                        (urlText.contains("auth") || urlText.contains("signin") || urlText.contains("authorize"))
                    if (isGoogleAuth || isAppleAuth) {
                        view.evaluateJavascript("window.alert('此登录方式暂不可用，请使用用户名登录。')", null)
                        return true
                    }
                    // Keep X and its required subdomains inside the app; external destinations are not launched.
                    return !(uri.scheme == "https" && (host == "x.com" || host.endsWith(".x.com") ||
                        host == "twitter.com" || host.endsWith(".twitter.com") ||
                        host == "twimg.com" || host.endsWith(".twimg.com")))
                }
                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    injectEntryGuard()
                    pageReady = true
                    lastKnownUrl = url
                }
            }
        }
        setContentView(web)
        if (savedInstanceState == null) {
            web.loadUrl(home)
        } else {
            val restored = web.restoreState(savedInstanceState)
            if (restored == null) web.loadUrl(savedInstanceState.getString("lastKnownUrl") ?: home)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else {
                    web.evaluateJavascript("history.length > 1") { canGo ->
                        if (canGo == "true") web.goBack() else finish()
                    }
                }
            }
        })
    }

    private fun injectEntryGuard() {
        val script = """
          (function(){
            if (window.__xWrapperGuardV3) return;
            window.__xWrapperGuardV3 = true;

            const norm = s => (s || '').toString().replace(/\s+/g, ' ').trim().toLowerCase();
            const blocked = {
              google: /google|谷歌/i,
              apple: /apple/i,
              phone: /phone|mobile|手机号|手机号码|电话号码|手机登录/i,
              app: /get\s*(the\s*)?app|download\s*(the\s*)?app|download.{0,24}\bapp\b|\bapp\b.{0,24}download|open\s*(the\s*)?app|获取应用|下载应用/i
            };
            function labelOf(el) {
              if (!el || !el.getAttribute) return '';
              return norm([el.innerText, el.textContent, el.getAttribute('aria-label'),
                el.getAttribute('title'), el.getAttribute('data-testid'), el.getAttribute('href'),
                el.getAttribute('name'), el.getAttribute('value')].filter(Boolean).join(' '));
            }
            function authRoot(el) {
              let n = el;
              for (let i=0; i<9 && n; i++, n=n.parentElement) {
                const t = norm(n.innerText || n.textContent);
                if (/(sign in|log in|登录|create your account|创建帐户)/i.test(t) &&
                    (/(use phone|continue with phone|phone number|手机号登录|使用手机号|手机号码)/i.test(t) ||
                     n.querySelector('input[type="tel"],input[autocomplete="tel"],input[name*="phone" i]'))) return n;
              }
              return null;
            }
            function phoneFlow(el) {
              if (authRoot(el)) return true;
              let n=el;
              for(let i=0;i<7 && n;i++,n=n.parentElement){
                if(n.querySelector && n.querySelector('input[type="tel"],input[autocomplete="tel"],input[name*="phone" i]')) return true;
                const t=norm(n.innerText || n.textContent);
                if(/(use phone|continue with phone|phone number|手机号登录|使用手机号|手机号码)/i.test(t)) return true;
              }
              return false;
            }
            function say(kind) {
              const msg = kind==='google' ? 'Google 登录暂不可用，请使用用户名登录。' :
                kind==='apple' ? 'Apple 登录暂不可用，请使用用户名登录。' :
                kind==='phone' ? '手机号登录暂不可用，请使用用户名登录。' :
                kind==='help' ? '帮助入口已停用。' : '此入口暂不可用。';
              try { window.alert(msg); } catch(e) {}
            }
            function classify(el) {
              const text=labelOf(el);
              const href=norm(el && el.getAttribute && el.getAttribute('href'));
              const data=norm(el && el.getAttribute && el.getAttribute('data-testid'));
              const all=text+' '+href+' '+data;
              if(blocked.google.test(all) && /(google|oauth|continue|sign.?in|log.?in|谷歌)/i.test(all)) return 'google';
              if(blocked.apple.test(all) && /(apple|oauth|continue|sign.?in|log.?in)/i.test(all)) return 'apple';
              if(blocked.app.test(all)) return 'app';
              // X 的手机号入口经常先打开号码表单，表单里的 Continue 按钮不含 phone 字样。
              if(blocked.phone.test(all) || /(use\s+phone(?:\s+or\s+email)?|phone\s+or\s+email|continue\s+with\s+phone|手机号或邮箱|使用电话或邮箱)/i.test(all) || (/(continue|next|继续)/i.test(all) && phoneFlow(el))) return 'phone';
              if(/^(help|帮助|help center|帮助中心|support|支持)$/i.test(text) || /help[-_ ]?(center)?|support/i.test(data)) return 'help';
              return '';
            }
            function intercept(e) {
              let el=e.target;
              for(let i=0;i<8 && el;i++,el=el.parentElement){
                if(!el.getAttribute) continue;
                const kind=classify(el);
                if(kind){
                  e.preventDefault(); e.stopPropagation();
                  if(e.stopImmediatePropagation) e.stopImmediatePropagation();
                  say(kind); return false;
                }
              }
            }
            // Capture before site handlers. Do not blanket-block generic Continue buttons:
            // only block them when the surrounding authentication flow is phone-based.
            document.addEventListener('click', intercept, true);
            document.addEventListener('pointerdown', intercept, true);
            document.addEventListener('keydown', function(e){
              if(e.key !== 'Enter' && e.key !== ' ') return;
              intercept(e);
            }, true);
            document.addEventListener('submit', function(e){
              const f=e.target;
              if(f && (f.querySelector('input[type="tel"],input[autocomplete="tel"],input[name*="phone" i]') || phoneFlow(f))){
                e.preventDefault(); e.stopPropagation(); if(e.stopImmediatePropagation)e.stopImmediatePropagation(); say('phone');
              }
            }, true);
            // X is a single-page app: keep the delegated guards alive as dialogs and login
            // steps are replaced dynamically. The listener is attached to document, not nodes.
            function removeHelpEntries(){
              const candidates=document.querySelectorAll('a,button,[role="button"],[data-testid],[aria-label],[title]');
              candidates.forEach(el=>{
                const t=norm([el.innerText,el.textContent,el.getAttribute('aria-label'),el.getAttribute('title'),el.getAttribute('data-testid')].filter(Boolean).join(' '));
                if(/^(help|help center|support|帮助|帮助中心|支持)$/.test(t) || /^(help|help-center|support)([-_ ]|$)/.test(norm(el.getAttribute('data-testid')))){
                  el.style.setProperty('display','none','important');
                  el.setAttribute('aria-hidden','true');
                  el.setAttribute('tabindex','-1');
                }
              });
            }
            function lockPhoneContinue(){
              const phoneInputs=document.querySelectorAll('input[type="tel"],input[autocomplete="tel"],input[name*="phone" i]');
              if(!phoneInputs.length) return;
              phoneInputs.forEach(input=>{
                let root=input;
                for(let i=0;i<7 && root.parentElement;i++) root=root.parentElement;
                root.querySelectorAll('button,[role="button"],input[type="submit"]').forEach(btn=>{
                  const t=norm(btn.innerText||btn.textContent||btn.getAttribute('aria-label'));
                  if(/^(continue|next|继续)$/.test(t)){
                    btn.setAttribute('aria-disabled','true');
                    btn.style.setProperty('pointer-events','none','important');
                    btn.style.setProperty('opacity','.45','important');
                  }
                });
              });
            }
            removeHelpEntries();
            const mo=new MutationObserver(function(){ removeHelpEntries(); lockPhoneContinue(); });
            if(document.documentElement) mo.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['aria-label','data-testid','title']});
          })();
        """.trimIndent()
        web.evaluateJavascript(script, null)
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.onResume()
    }

    override fun onPause() {
        if (::web.isInitialized) {
            web.onPause()
            CookieManager.getInstance().flush()
        }
        super.onPause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web.saveState(outState)
        outState.putString("lastKnownUrl", web.url ?: lastKnownUrl ?: home)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        if (::web.isInitialized) { web.stopLoading(); web.destroy() }
        super.onDestroy()
    }
}
